FamiTracker Readme
------------------

FamiTracker is an application designed to create music for the NES/Famicom systems
and is distributed under the GNU GPL license. Windows XP or later and a DirectX 
compatible sound card is required to run this software. More information can be 
found in the help files or on the web page.

For a compendium of frequently asked questions, please visit this link:
http://www.famitracker.com/wiki/index.php?title=Frequently_Asked_Questions

To uninstall, run "famitracker.exe /unregister". This will remove the file association.

If you have problems viewing the help files, right click it (FamiTracker.chm) and 
open properties, then click the "Unblock" button in the general tab.

Web page:      http://www.famitracker.com
Author's mail: jsr@famitracker.com


Changelog (v0.4.6)
------------------
  - Pattern rows with unspecified instruments will use the selected instrument 
  - Fixed some rendering bugs 
  - Fixed instrument clone command bug 
